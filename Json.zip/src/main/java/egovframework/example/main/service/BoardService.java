package egovframework.example.main.service;

import java.util.List;
import egovframework.example.main.dto.BoardVO;

public interface BoardService {

	public List<BoardVO> selectAll() throws Exception;
	
	public BoardVO selectOne(int board_id) throws Exception;
	public void addBoard(BoardVO vo) throws Exception;
	public void updateBoard(BoardVO vo) throws Exception;
	public void deleteBoard(int id) throws Exception;

}
