package egovframework.example.main.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.example.main.dto.BoardVO;
import egovframework.example.main.mapper.BoardMapper;

@Service("boardService")
public class BoardServiceImpl implements BoardService {

	@Resource(name = "boardMapper")
	private BoardMapper boardMapper;

	public List<BoardVO> selectAll() throws Exception {

		return boardMapper.selectAll();

	}
	public void addBoard(BoardVO vo) throws Exception {
		// TODO Auto-generated method stub
		boardMapper.addBoard(vo);
	}

	public void updateBoard(BoardVO vo) throws Exception {
		// TODO Auto-generated method stub
		boardMapper.updateBoard(vo);
	}

	public void deleteBoard(int board_id) throws Exception {
		// TODO Auto-generated method stub
		boardMapper.deleteBoard(board_id);
	}
	
	//글 한개 가져오기
	
	@Override
	public BoardVO selectOne(int board_id) throws Exception {
		
			return boardMapper.selectOne(board_id);		
		
		
	}




}
