package egovframework.example.main.mapper;

import java.util.List;

import egovframework.example.main.dto.BoardVO;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("boardMapper")
public interface BoardMapper {

	List<BoardVO> selectAll() throws Exception;
	
	BoardVO selectOne(int board_id) throws Exception;
	
	//글쓰기
	void addBoard(BoardVO vo) throws Exception;
	//글 수정
	void updateBoard(BoardVO vo) throws Exception;
	//글 삭제
	void deleteBoard(int board_id) throws Exception;
	
	
}