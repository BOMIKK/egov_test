package egovframework.example.main.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import egovframework.example.main.dto.BoardVO;
import egovframework.example.main.service.BoardService;

@Controller
public class MainController {

	@Autowired
	private BoardService boardservice;

	/**
	 * Simply selects the home view to render by returning its name.
	 * 
	 * @throws Exception
	 */

	@RequestMapping(value = "/main.do", method = RequestMethod.GET)
	public String main(Model model) throws Exception {
		List<BoardVO> boardList = boardservice.selectAll();
		System.out.println("메인페이지 매핑 ");
		model.addAttribute("boardList", boardList);

		return "main";
	}

	// 글쓰기 버튼 매핑
	@RequestMapping(value = "/board/boardWrite.do")
	public String boardWrite() throws Exception {

		return "boardForm";
	}

	// 글 수정 버튼 매핑
	@RequestMapping(value = "/board/boardUpdate.do")
	public String boardUpdate(@RequestParam("id") int board_id,Model model) throws Exception {
		//System.out.println("글수정 매핑 board_id " + board_id);
		BoardVO boardOne=boardservice.selectOne(board_id);
		System.out.println("글수정 매핑 " + board_id +":"+ boardOne);
		
		model.addAttribute("boardOne", boardOne);
		model.addAttribute("board_id", board_id);
		return "modiboardForm";
	}

	// 글 삭제 버튼 매핑
	@RequestMapping(value = "/board/boardDelete.do")
	//Url 에서 값 가져오기 @RequestParam
	public String boardDelete(@RequestParam("id") int board_id) throws Exception {
		
		//System.out.println("글삭제 매핑 " + board_id);
		boardservice.deleteBoard(board_id);
		
		return "redirect:/main.do";
	}

	
	
	// 나중에 board컨트롤러로 바꾸기
	@RequestMapping(value = "/addBoard.do", method = RequestMethod.POST)
	public String addBoard(BoardVO vo) throws Exception {

		//System.out.println("글쓰기 매핑 " + vo.getId() + vo.getTitle());
		boardservice.addBoard(vo);

		return "redirect:main.do";
	}
	
	// 나중에 board컨트롤러로 바꾸기
		@RequestMapping(value = "/updateBoard.do", method = RequestMethod.POST)
		public String updateBoard(BoardVO vo) throws Exception {

			//System.out.println("글쓰기 매핑 " + vo.getId() + vo.getTitle());
			boardservice.updateBoard(vo);

			return "redirect:main.do";
		}



}